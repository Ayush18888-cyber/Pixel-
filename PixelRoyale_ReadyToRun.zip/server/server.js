
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

let players = [];

// Serve static files
app.use(express.static('client'));

// Handle new player connections
io.on('connection', (socket) => {
  console.log('New player connected: ' + socket.id);

  socket.on('newPlayer', (data) => {
    players.push({ id: socket.id, x: data.x, y: data.y, size: data.size });
    io.emit('newBot', { id: socket.id, x: data.x, y: data.y, size: data.size });
  });

  socket.on('shoot', (bullet) => {
    io.emit('shoot', bullet);
  });

  socket.on('disconnect', () => {
    players = players.filter(player => player.id !== socket.id);
    io.emit('playerDisconnected', socket.id);
    console.log('Player disconnected: ' + socket.id);
  });
});

// Start the server
server.listen(3000, () => {
  console.log('Server is running on http://localhost:3000');
});
