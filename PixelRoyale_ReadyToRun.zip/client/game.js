
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let player = {
  x: canvas.width / 2,
  y: canvas.height / 2,
  size: 20,
  speed: 5,
  dx: 0,
  dy: 0
};

let bullets = [];
let bots = [];

const socket = io.connect('http://localhost:3000');

socket.on('connect', () => {
  console.log("Connected to server!");
  socket.emit('newPlayer', { x: player.x, y: player.y, size: player.size });
});

// Handle player movement
document.addEventListener('keydown', (e) => {
  if (e.key === 'w') player.dy = -player.speed;
  if (e.key === 's') player.dy = player.speed;
  if (e.key === 'a') player.dx = -player.speed;
  if (e.key === 'd') player.dx = player.speed;
});

document.addEventListener('keyup', (e) => {
  if (e.key === 'w' || e.key === 's') player.dy = 0;
  if (e.key === 'a' || e.key === 'd') player.dx = 0;
});

// Handle bullet firing
document.addEventListener('click', () => {
  let bullet = { x: player.x, y: player.y, dx: 10, dy: 0 };
  bullets.push(bullet);
  socket.emit('shoot', bullet);
});

// Game loop
function gameLoop() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  player.x += player.dx;
  player.y += player.dy;

  // Draw player
  ctx.fillStyle = 'blue';
  ctx.fillRect(player.x - player.size / 2, player.y - player.size / 2, player.size, player.size);

  // Draw bots
  bots.forEach((bot) => {
    ctx.fillStyle = 'red';
    ctx.fillRect(bot.x - bot.size / 2, bot.y - bot.size / 2, bot.size, bot.size);
  });

  // Draw bullets
  bullets.forEach((bullet, index) => {
    bullet.x += bullet.dx;
    bullet.y += bullet.dy;
    ctx.fillStyle = 'yellow';
    ctx.fillRect(bullet.x, bullet.y, 10, 5);
  });

  requestAnimationFrame(gameLoop);
}

// Listen for new bots
socket.on('newBot', (botData) => {
  bots.push(botData);
});

// Start game loop
gameLoop();
